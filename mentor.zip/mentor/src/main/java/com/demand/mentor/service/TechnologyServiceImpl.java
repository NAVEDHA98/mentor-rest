package com.demand.mentor.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demand.mentor.dao.TechnologyDao;
import com.demand.mentor.model.Technology;

@Service
public class TechnologyServiceImpl implements TechnologyService {
	@Autowired
	TechnologyDao technologyDao;

	public List<Technology> getAlltechnology() {
		return technologyDao.findAll();
	}

	public Technology addTechnology(Technology technology) {
		Technology t = technologyDao.save(technology);
		return t;
	}
}

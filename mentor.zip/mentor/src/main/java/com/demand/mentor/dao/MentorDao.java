package com.demand.mentor.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.demand.mentor.model.Mentor;

public interface MentorDao extends JpaRepository<Mentor, Integer> {
	public Mentor findByEmailId(String name);

	public List<Mentor> findByStatus(String status);

	@Modifying(clearAutomatically = true)
	@Transactional
	@Query("Update Mentor SET status = 'blocked' where mentorId = :mentorId")
	void setMentorStatus(@Param("mentorId") int mentorId);

	public Mentor findByMentorId(int mentorId);

	public List<Mentor> findByTechnology(String technology);
}

package com.demand.mentor.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demand.mentor.model.Admin;

public interface AdminDao extends JpaRepository<Admin, Integer> {
	public Admin findByEmailId(String name);
}

package com.demand.mentor.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demand.mentor.model.Technology;

public interface TechnologyDao extends JpaRepository<Technology, Integer> {

}

package com.demand.mentor.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demand.mentor.model.Mentor;
import com.demand.mentor.model.Technology;
import com.demand.mentor.model.User;
import com.demand.mentor.service.MentorService;
import com.demand.mentor.service.TechnologyService;
import com.demand.mentor.service.UserService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class AdminRestController {

	@Autowired
	TechnologyService technologyService;

	@Autowired
	UserService userService;

	@Autowired
	MentorService mentorService;

	@GetMapping(path = "/technologies")
	public List<Technology> getAllTechnology() {
		return technologyService.getAlltechnology();
	}

	@PostMapping(path = "/addTechnology/{technology}")
	public Technology addTechnology(@PathVariable Technology technology) {
		System.out.println("Adding Technology");
		Technology _technology = technologyService.addTechnology(technology);
		return _technology;
	}

	@GetMapping(path = "/userBlockPage")
	public List<User> userBlockPage() {
		System.out.println("Fetching Unblocked Users");
		List<User> userUnblockedDetails = userService.getAllUnblockedUser("unblocked");
		return userUnblockedDetails;
	}

	@GetMapping(value = "/blockUser/{userId}")
	public ResponseEntity<String> blockUser(@PathVariable("userId") int id) {
		System.out.println("Blocked the user with ID " + id);
		userService.blockUser(id);
		return new ResponseEntity<>("User has been blocked", HttpStatus.OK);
	}

	@GetMapping(path = "/mentorBlockPage")
	public List<Mentor> mentorBlockPage() {
		System.out.println("Fetching Unblocked Mentors");
		List<Mentor> mentorUnblockedDetails = mentorService.getAllUnblockedMentor("unblocked");
		return mentorUnblockedDetails;
	}

	@GetMapping(value = "/blockMentor/{mentorId}")
	public ResponseEntity<String> blockMentor(@PathVariable("mentorId") int id) {
		System.out.println("Blocked the mentor with ID " + id);
		mentorService.blockMentor(id);
		return new ResponseEntity<>("Mentor has been blocked", HttpStatus.OK);
	}
}
//
// @RequestMapping(value = "/browseHistory", method = { RequestMethod.POST,
// RequestMethod.GET })
// public ModelAndView browseHistory(HttpServletRequest request) {
// ModelAndView mav = null;
//
// HttpSession session = request.getSession(false);
// Admin admin = (Admin) session.getAttribute("adminDetails");
//
// if (admin != null) {
// mav = new ModelAndView("PaymentHistoryPage");
// } else {
// mav = new ModelAndView("HomePage");
// }
// return mav;
// }

// @RequestMapping(value = "/logoutAdmin", method = RequestMethod.POST)
// public ModelAndView logoutAdmin(HttpServletRequest request) throws
// IOException {
// ModelAndView mav = null;
//
// HttpSession session = request.getSession(false);
//
// session.invalidate();
//
// mav = new ModelAndView("HomePage");
//
// return mav;
// }

package com.demand.mentor.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.demand.mentor.model.Login;
import com.demand.mentor.model.Mentor;
import com.demand.mentor.service.LoginService;
import com.demand.mentor.service.MentorService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class MentorRestController {

	@Autowired
	LoginService loginService;

	@Autowired
	MentorService mentorService;

	@PostMapping(path = "/mentorRegister")
	public Mentor insertUser(@RequestBody Mentor mentor) {
		System.out.println("Inserting mentor record");
		Mentor _mentor = mentorService.insertMentor(mentor);
		Login _login = loginService.insertLoginDetails(mentor);
		System.out.println("\n" + _login);
		return _mentor;
	}
}

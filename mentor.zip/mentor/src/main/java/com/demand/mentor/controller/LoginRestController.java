package com.demand.mentor.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.demand.mentor.model.Login;
import com.demand.mentor.model.LoginPojo;
import com.demand.mentor.service.LoginService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class LoginRestController {

	@Autowired
	LoginService loginService;

	@PostMapping(path = "/login")
	public ResponseEntity<String> userLoginProcess(@RequestBody LoginPojo loginPojo) {

		List<Login> loginDetails = loginService.getAllLoginDetails();

		for (Login login : loginDetails) {
			if (loginPojo.getUserName().equals(login.getUserName())
					&& loginPojo.getPassword().equals(login.getPassword())) {
				if (login.getUserType().equals("user")) {
					if (login.getStatus().equals("blocked")) {
						return new ResponseEntity<String>("Your account is blocked", HttpStatus.UNAUTHORIZED);
					} else {
						return new ResponseEntity<String>("Successfully logged in", HttpStatus.OK);
					}
				} else if (login.getUserType().equals("mentor")) {
					if (login.getStatus().equals("blocked")) {
						return new ResponseEntity<String>("Your account is blocked", HttpStatus.UNAUTHORIZED);
					} else {
						return new ResponseEntity<String>("Successfully logged in", HttpStatus.OK);
					}
				} else {
					return new ResponseEntity<String>("Successfully logged in", HttpStatus.OK);
				}
			}
		}
		return null;
	}
}

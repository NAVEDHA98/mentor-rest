package com.demand.mentor.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demand.mentor.dao.LoginDao;
import com.demand.mentor.dao.MentorDao;
import com.demand.mentor.model.Login;
import com.demand.mentor.model.Mentor;

@Service
public class MentorServiceImpl implements MentorService {
	@Autowired
	MentorDao mentorDao;

	@Autowired
	LoginDao loginDao;

	public Mentor insertMentor(Mentor mentor) {
		return mentorDao.save(mentor);
	}

	public Mentor getMentorDetails(String name) {
		return mentorDao.findByEmailId(name);
	}

	public List<Mentor> getAllUnblockedMentor(String status) {
		return mentorDao.findByStatus(status);
	}

	public int blockMentor(int mentorId) {
		mentorDao.setMentorStatus(mentorId);
		Mentor mentor = mentorDao.findByMentorId(mentorId);

		Login login = loginDao.findByUserName(mentor.getEmailId());
		int loginId = login.getLoginId();
		loginDao.setLoginStatus(loginId);

		return 1;
	}

	public List<Mentor> getSearchMentor(String technology) {
		return mentorDao.findByTechnology(technology);
	}
}

package com.demand.mentor.service;

import java.util.List;

import com.demand.mentor.model.User;

public interface UserService {

	public User insertUser(User user);

	public List<User> getAllUserDetails();

	public User getUserDetails(String name);

	public List<User> getAllUnblockedUser(String status);

	public int blockUser(int userId);

}

package com.demand.mentor.service;

import java.util.List;

import com.demand.mentor.model.Mentor;

public interface MentorService {
	public Mentor insertMentor(Mentor mentor);

	public Mentor getMentorDetails(String name);

	public List<Mentor> getAllUnblockedMentor(String status);

	public int blockMentor(int mentorId);

	public List<Mentor> getSearchMentor(String technology);
}

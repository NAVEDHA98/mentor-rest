package com.demand.mentor.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.demand.mentor.model.Login;
import com.demand.mentor.model.Mentor;
import com.demand.mentor.model.User;
import com.demand.mentor.service.LoginService;
import com.demand.mentor.service.MentorService;
import com.demand.mentor.service.UserService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class UserRestController {
	@Autowired
	UserService userService;

	@Autowired
	LoginService loginService;

	@Autowired
	MentorService mentorService;

	@PostMapping(path = "/userRegister")
	public User insertUser(@RequestBody User user) {
		System.out.println("Inserting User");
		User _user = userService.insertUser(user);
		Login _login = loginService.insertLoginDetails(user);
		System.out.println("\n" + _login);
		return _user;
	}

	@GetMapping(path = "/searchMentor/{technology}")
	public List<Mentor> searchMentor(@PathVariable("technology") String technology) {
		System.out.println("List of Mentors under " + technology);
		List<Mentor> mentorSearchDetails = mentorService.getSearchMentor(technology);
		return mentorSearchDetails;
	}
}
